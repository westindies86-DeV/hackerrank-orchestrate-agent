﻿import json
import os
from pathlib import Path
from damage_analyzer import DamageAnalyzer

def main():
    base_path = Path(__file__).parent.parent
    input_path = base_path / "data" / "input.json"
    output_path = base_path / "output.json"
    
    api_key = os.getenv("MISTRAL_API_KEY")
    if not api_key:
        raise ValueError("MISTRAL_API_KEY not set")
    
    analyzer = DamageAnalyzer(api_key=api_key, base_path=str(base_path))
    
    with open(input_path) as f:
        claims = json.load(f)
    
    results = []
    for claim in claims:
        print(f"Processing claim for user_id: {claim['user_id']}")
        try:
            result = analyzer.analyze_claim(claim)
            results.append(result)
            print(f"  Result: damage={result['damage_detected']}, matches={result['matches_claim']}")
        except Exception as e:
            print(f"  Error: {e}")
            results.append({"user_id": claim["user_id"], "error": str(e)})
    
    with open(output_path, "w") as f:
        json.dump(results, f, indent=2)
    
    print(f"\nDone. Wrote {len(results)} results to {output_path}")

if __name__ == "__main__":
    main()
